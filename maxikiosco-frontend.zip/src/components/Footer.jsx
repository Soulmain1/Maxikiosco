function Footer() {
  return (
    <footer className="bg-gray-800 text-white text-center p-2 mt-4">
      © 2025 Maxikiosco - Todos los derechos reservados
    </footer>
  );
}

export default Footer;
