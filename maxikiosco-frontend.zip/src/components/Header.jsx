function Header() {
  return (
    <header className="bg-yellow-400 p-4 text-center font-bold text-lg">
      Maxikiosco Online
    </header>
  );
}

export default Header;
