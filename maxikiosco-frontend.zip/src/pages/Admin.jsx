function Admin() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Panel de Administración</h1>
      <p>Vista administrativa (solo diseño).</p>
    </div>
  );
}

export default Admin;
