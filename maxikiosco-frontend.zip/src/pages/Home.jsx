function Home() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Catálogo de Productos</h1>
      <p>Aquí se mostrará la lista de productos del Maxikiosco.</p>
    </div>
  );
}

export default Home;
