function Login() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Iniciar Sesión</h1>
      <p>Formulario de login (solo diseño).</p>
    </div>
  );
}

export default Login;
